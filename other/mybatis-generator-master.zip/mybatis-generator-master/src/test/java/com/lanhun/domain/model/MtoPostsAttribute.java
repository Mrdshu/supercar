package com.lanhun.domain.model;



/**
 * <p>
 * 
 *
 *
 * </p>
 * 
 * @author hz15101769
 * @date 2016-01-12 16:11:46
 * @version
 */
public class MtoPostsAttribute {
		
	    
	private String videoUrl;
		
	    
	private Long id;
		
	    
	private String videoBody;
		
	
		
	public String getVideoUrl() {
        return videoUrl;
    }

	public void setVideoUrl(String videoUrl) {
    	 this.videoUrl = videoUrl;
	}
		
	public Long getId() {
        return id;
    }

	public void setId(Long id) {
    	 this.id = id;
	}
		
	public String getVideoBody() {
        return videoBody;
    }

	public void setVideoBody(String videoBody) {
    	 this.videoBody = videoBody;
	}
	}