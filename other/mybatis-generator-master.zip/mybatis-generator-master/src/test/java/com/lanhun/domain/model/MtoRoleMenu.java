package com.lanhun.domain.model;



/**
 * <p>
 * 
 *
 *
 * </p>
 * 
 * @author hz15101769
 * @date 2016-01-12 16:11:45
 * @version
 */
public class MtoRoleMenu {
		
	    
	private Long roleId;
		
	    
	private Long menuId;
		
	
		
	public Long getRoleId() {
        return roleId;
    }

	public void setRoleId(Long roleId) {
    	 this.roleId = roleId;
	}
		
	public Long getMenuId() {
        return menuId;
    }

	public void setMenuId(Long menuId) {
    	 this.menuId = menuId;
	}
	}