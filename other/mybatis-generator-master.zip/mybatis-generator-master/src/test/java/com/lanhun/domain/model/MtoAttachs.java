package com.lanhun.domain.model;



/**
 * <p>
 * 
 *
 *
 * </p>
 * 
 * @author hz15101769
 * @date 2016-01-12 16:11:46
 * @version
 */
public class MtoAttachs {
		
	    
	private String preview;
		
	    
	private String original;
		
	    
	private Integer width;
		
	    
	private Long toId;
		
	    
	private Long id;
		
	    
	private String screenshot;
		
	    
	private Integer store;
		
	    
	private Integer height;
		
	    
	private Integer status;
		
	
		
	public String getPreview() {
        return preview;
    }

	public void setPreview(String preview) {
    	 this.preview = preview;
	}
		
	public String getOriginal() {
        return original;
    }

	public void setOriginal(String original) {
    	 this.original = original;
	}
		
	public Integer getWidth() {
        return width;
    }

	public void setWidth(Integer width) {
    	 this.width = width;
	}
		
	public Long getToId() {
        return toId;
    }

	public void setToId(Long toId) {
    	 this.toId = toId;
	}
		
	public Long getId() {
        return id;
    }

	public void setId(Long id) {
    	 this.id = id;
	}
		
	public String getScreenshot() {
        return screenshot;
    }

	public void setScreenshot(String screenshot) {
    	 this.screenshot = screenshot;
	}
		
	public Integer getStore() {
        return store;
    }

	public void setStore(Integer store) {
    	 this.store = store;
	}
		
	public Integer getHeight() {
        return height;
    }

	public void setHeight(Integer height) {
    	 this.height = height;
	}
		
	public Integer getStatus() {
        return status;
    }

	public void setStatus(Integer status) {
    	 this.status = status;
	}
	}