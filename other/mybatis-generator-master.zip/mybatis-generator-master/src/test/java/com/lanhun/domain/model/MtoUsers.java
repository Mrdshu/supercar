package com.lanhun.domain.model;


import java.util.Date;


/**
 * <p>
 * 
 *
 *
 * </p>
 * 
 * @author hz15101769
 * @date 2016-01-12 16:11:46
 * @version
 */
public class MtoUsers {
		
	    
	private Integer comments;
		
	    
	private Integer gender;
		
	    
	private String signature;
		
			   	
   	 /**
     * 创建时间
     */
        
	private Date created;
		
	    
	private Date lastLogin;
		
	    
	private String mobile;
		
	    
	private Integer follows;
		
	    
	private Integer favors;
		
	    
	private String avatar;
		
	    
	private Integer source;
		
	    
	private Integer posts;
		
	    
	private Integer fans;
		
	    
	private String password;
		
	    
	private Integer roleId;
		
	    
	private String name;
		
	    
	private Long id;
		
	    
	private Integer activeEmail;
		
	    
	private Date updated;
		
	    
	private String email;
		
	    
	private Integer status;
		
	    
	private String username;
		
	
		
	public Integer getComments() {
        return comments;
    }

	public void setComments(Integer comments) {
    	 this.comments = comments;
	}
		
	public Integer getGender() {
        return gender;
    }

	public void setGender(Integer gender) {
    	 this.gender = gender;
	}
		
	public String getSignature() {
        return signature;
    }

	public void setSignature(String signature) {
    	 this.signature = signature;
	}
		
	public Date getCreated() {
        return created;
    }

	public void setCreated(Date created) {
    	 this.created = created;
	}
		
	public Date getLastLogin() {
        return lastLogin;
    }

	public void setLastLogin(Date lastLogin) {
    	 this.lastLogin = lastLogin;
	}
		
	public String getMobile() {
        return mobile;
    }

	public void setMobile(String mobile) {
    	 this.mobile = mobile;
	}
		
	public Integer getFollows() {
        return follows;
    }

	public void setFollows(Integer follows) {
    	 this.follows = follows;
	}
		
	public Integer getFavors() {
        return favors;
    }

	public void setFavors(Integer favors) {
    	 this.favors = favors;
	}
		
	public String getAvatar() {
        return avatar;
    }

	public void setAvatar(String avatar) {
    	 this.avatar = avatar;
	}
		
	public Integer getSource() {
        return source;
    }

	public void setSource(Integer source) {
    	 this.source = source;
	}
		
	public Integer getPosts() {
        return posts;
    }

	public void setPosts(Integer posts) {
    	 this.posts = posts;
	}
		
	public Integer getFans() {
        return fans;
    }

	public void setFans(Integer fans) {
    	 this.fans = fans;
	}
		
	public String getPassword() {
        return password;
    }

	public void setPassword(String password) {
    	 this.password = password;
	}
		
	public Integer getRoleId() {
        return roleId;
    }

	public void setRoleId(Integer roleId) {
    	 this.roleId = roleId;
	}
		
	public String getName() {
        return name;
    }

	public void setName(String name) {
    	 this.name = name;
	}
		
	public Long getId() {
        return id;
    }

	public void setId(Long id) {
    	 this.id = id;
	}
		
	public Integer getActiveEmail() {
        return activeEmail;
    }

	public void setActiveEmail(Integer activeEmail) {
    	 this.activeEmail = activeEmail;
	}
		
	public Date getUpdated() {
        return updated;
    }

	public void setUpdated(Date updated) {
    	 this.updated = updated;
	}
		
	public String getEmail() {
        return email;
    }

	public void setEmail(String email) {
    	 this.email = email;
	}
		
	public Integer getStatus() {
        return status;
    }

	public void setStatus(Integer status) {
    	 this.status = status;
	}
		
	public String getUsername() {
        return username;
    }

	public void setUsername(String username) {
    	 this.username = username;
	}
	}