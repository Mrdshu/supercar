package com.lanhun.domain.model;



/**
 * <p>
 * 
 *
 *
 * </p>
 * 
 * @author hz15101769
 * @date 2016-01-12 16:11:46
 * @version
 */
public class MtoGroup {
		
	    
	private String template;
		
	    
	private String key;
		
	    
	private String name;
		
	    
	private String icon;
		
	    
	private String alias;
		
	    
	private Integer id;
		
	    
	private Integer status;
		
	
		
	public String getTemplate() {
        return template;
    }

	public void setTemplate(String template) {
    	 this.template = template;
	}
		
	public String getKey() {
        return key;
    }

	public void setKey(String key) {
    	 this.key = key;
	}
		
	public String getName() {
        return name;
    }

	public void setName(String name) {
    	 this.name = name;
	}
		
	public String getIcon() {
        return icon;
    }

	public void setIcon(String icon) {
    	 this.icon = icon;
	}
		
	public String getAlias() {
        return alias;
    }

	public void setAlias(String alias) {
    	 this.alias = alias;
	}
		
	public Integer getId() {
        return id;
    }

	public void setId(Integer id) {
    	 this.id = id;
	}
		
	public Integer getStatus() {
        return status;
    }

	public void setStatus(Integer status) {
    	 this.status = status;
	}
	}