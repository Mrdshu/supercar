package com.lanhun.domain.model;



/**
 * <p>
 * 
 *角色
 *
 * </p>
 * 
 * @author hz15101769
 * @date 2016-01-12 16:11:45
 * @version
 */
public class MtoRole {
		
			   	
   	 /**
     * 角色名
     */
        
	private String name;
		
	    
	private Long id;
		
	
		
	public String getName() {
        return name;
    }

	public void setName(String name) {
    	 this.name = name;
	}
		
	public Long getId() {
        return id;
    }

	public void setId(Long id) {
    	 this.id = id;
	}
	}