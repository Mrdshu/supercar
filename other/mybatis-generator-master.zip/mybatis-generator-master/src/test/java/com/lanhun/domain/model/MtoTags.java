package com.lanhun.domain.model;



/**
 * <p>
 * 
 *
 *
 * </p>
 * 
 * @author hz15101769
 * @date 2016-01-12 16:11:46
 * @version
 */
public class MtoTags {
		
	    
	private Integer featured;
		
	    
	private Integer hots;
		
	    
	private Long lastPostId;
		
	    
	private String name;
		
	    
	private Long id;
		
	    
	private Integer locked;
		
	    
	private Integer posts;
		
	
		
	public Integer getFeatured() {
        return featured;
    }

	public void setFeatured(Integer featured) {
    	 this.featured = featured;
	}
		
	public Integer getHots() {
        return hots;
    }

	public void setHots(Integer hots) {
    	 this.hots = hots;
	}
		
	public Long getLastPostId() {
        return lastPostId;
    }

	public void setLastPostId(Long lastPostId) {
    	 this.lastPostId = lastPostId;
	}
		
	public String getName() {
        return name;
    }

	public void setName(String name) {
    	 this.name = name;
	}
		
	public Long getId() {
        return id;
    }

	public void setId(Long id) {
    	 this.id = id;
	}
		
	public Integer getLocked() {
        return locked;
    }

	public void setLocked(Integer locked) {
    	 this.locked = locked;
	}
		
	public Integer getPosts() {
        return posts;
    }

	public void setPosts(Integer posts) {
    	 this.posts = posts;
	}
	}