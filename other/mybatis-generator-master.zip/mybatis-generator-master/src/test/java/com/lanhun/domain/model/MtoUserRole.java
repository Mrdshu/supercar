package com.lanhun.domain.model;



/**
 * <p>
 * 
 *
 *
 * </p>
 * 
 * @author hz15101769
 * @date 2016-01-12 16:11:46
 * @version
 */
public class MtoUserRole {
		
	    
	private Long userId;
		
	    
	private Long roleId;
		
	
		
	public Long getUserId() {
        return userId;
    }

	public void setUserId(Long userId) {
    	 this.userId = userId;
	}
		
	public Long getRoleId() {
        return roleId;
    }

	public void setRoleId(Long roleId) {
    	 this.roleId = roleId;
	}
	}