package com.lanhun.framework.generator.custom;

/**
 * 自定义配置文件
 * @author wangsz 2017-07-04
 */
public class CustomConfig {
	
}
