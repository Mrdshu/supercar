package com.lanhun.framework.generator.core;

public enum DBType {
	MySql, SqlServer;
}
