package com.lanhun.framework.generator.utils;

public class CustomUtil {

}
