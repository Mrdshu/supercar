package com.lanhun.domain.model;



/**
 * <p>
 * 
 *
 *
 * </p>
 * 
 * @author hz15101769
 * @date 2016-01-12 16:11:45
 * @version
 */
public class MtoFriendLink {
		
	    
	private String siteName;
		
	    
	private String logo;
		
	    
	private String remark;
		
	    
	private Long id;
		
	    
	private Integer sort;
		
	    
	private String url;
		
	
		
	public String getSiteName() {
        return siteName;
    }

	public void setSiteName(String siteName) {
    	 this.siteName = siteName;
	}
		
	public String getLogo() {
        return logo;
    }

	public void setLogo(String logo) {
    	 this.logo = logo;
	}
		
	public String getRemark() {
        return remark;
    }

	public void setRemark(String remark) {
    	 this.remark = remark;
	}
		
	public Long getId() {
        return id;
    }

	public void setId(Long id) {
    	 this.id = id;
	}
		
	public Integer getSort() {
        return sort;
    }

	public void setSort(Integer sort) {
    	 this.sort = sort;
	}
		
	public String getUrl() {
        return url;
    }

	public void setUrl(String url) {
    	 this.url = url;
	}
	}