package com.lanhun.domain.model;



/**
 * <p>
 * 
 *
 *
 * </p>
 * 
 * @author hz15101769
 * @date 2016-01-12 16:11:46
 * @version
 */
public class MtoMenu {
		
	    
	private String name;
		
	    
	private Integer weight;
		
	    
	private Integer id;
		
	    
	private String url;
		
	    
	private String target;
		
	    
	private Integer status;
		
	
		
	public String getName() {
        return name;
    }

	public void setName(String name) {
    	 this.name = name;
	}
		
	public Integer getWeight() {
        return weight;
    }

	public void setWeight(Integer weight) {
    	 this.weight = weight;
	}
		
	public Integer getId() {
        return id;
    }

	public void setId(Integer id) {
    	 this.id = id;
	}
		
	public String getUrl() {
        return url;
    }

	public void setUrl(String url) {
    	 this.url = url;
	}
		
	public String getTarget() {
        return target;
    }

	public void setTarget(String target) {
    	 this.target = target;
	}
		
	public Integer getStatus() {
        return status;
    }

	public void setStatus(Integer status) {
    	 this.status = status;
	}
	}