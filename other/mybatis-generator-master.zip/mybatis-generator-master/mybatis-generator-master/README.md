# mybatis-generator
基于velocity的 mybatis 代码生成
